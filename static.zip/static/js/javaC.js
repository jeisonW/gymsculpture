var eye =  document.querySelector('#eye');

function mostrar() {
    let password =  document.querySelector('#password');

    if(password.type === 'password') {
        password.type = 'text';
        eye.style.opacity = 0.3
    } else {
        password.type = 'password';
        eye.style.opacity = 0.8
    }
}

eye.addEventListener('click', mostrar);


